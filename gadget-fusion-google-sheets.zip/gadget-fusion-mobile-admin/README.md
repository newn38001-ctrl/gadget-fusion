# Gadget Fusion — মোবাইল Admin Panel সহ

## কী আছে
- আগের Gadget Fusion ডিজাইন এবং ৫টি পণ্য ও তাদের মূল ছবি
- বাংলা/ইংরেজি storefront
- ফোনের Gallery থেকে পণ্যের ছবি আপলোড (JPG, PNG, WEBP, GIF; সর্বোচ্চ 5 MB)
- পণ্যের নাম, দাম, আগের দাম, বিবরণ, ক্যাটাগরি, ছবি ও show/hide পরিবর্তন
- হোমপেজের শিরোনাম, লেখা, ব্যানার ছবি, WhatsApp/ফোন নম্বর, পরিচিতি ও ডেলিভারি চার্জ পরিবর্তন
- অর্ডার সংরক্ষণ ও Admin Panel থেকে status পরিবর্তন
- আলাদা Admin Login

## Replit-এ চালানোর নিয়ম (Android ফোন থেকেও)
1. এই ZIP Replit-এ Import করুন।
2. Replit Shell-এ `npm install` চালান।
3. Secrets / Environment Variables-এ `.env.example`-এর মানগুলো যোগ করুন। `SESSION_SECRET`-এ অন্তত 32 অক্ষরের নতুন random secret এবং `ADMIN_PASSWORD`-এ অন্তত 12 অক্ষরের শক্ত পাসওয়ার্ড দিন।
4. Run command `npm start` রাখুন।
5. Preview খুলে storefront দেখুন। Admin Panel: `/admin.html`।
6. Admin Login-এ আপনার `ADMIN_EMAIL` ও `ADMIN_PASSWORD` ব্যবহার করুন।

## ডেটা সংরক্ষণ
`data/` ফোল্ডারে products, settings, orders এবং SQLite session database থাকে। `public/uploads/`-এ আপলোড করা ছবি থাকে। Hosting provider-এ persistent disk/volume যুক্ত করতে হবে এবং এই ফোল্ডারগুলো deploy/restart-এর পরও সংরক্ষিত থাকে কি না নিশ্চিত করতে হবে। শুধু ephemeral filesystem-এ চালালে redeploy হলে ডেটা/ছবি হারাতে পারে।

## গুরুত্বপূর্ণ সীমাবদ্ধতা ও প্রকাশের আগে করণীয়
- এই প্যাকেজে কোনো online payment gateway নেই। Storefront-এর অর্ডার WhatsApp-এ পাঠানো হয় এবং একই সঙ্গে server-এ order record তৈরি হয়।
- বর্তমান অর্ডার flow পণ্যের stock কমায় না; inventory accounting যোগ করা দরকার হলে পরের ধাপে করা যাবে।
- Admin password environment variables-এ রাখুন; `.env` কখনো public repository-তে commit করবেন না।
- HTTPS-সহ hosting ব্যবহার করুন, persistent storage নিশ্চিত করুন, নিজের ফোনে customer order এবং admin edits পরীক্ষা করুন।
- এই build-এর source files তৈরি ও syntax-check করা হয়েছে; এখানে live hosting, payment, real device end-to-end testing বা production security audit করা হয়নি। তাই যাচাই ছাড়া production-ready ধরে নেবেন না।

## ডিফল্ট লগইন
কোডে fallback credentials আছে শুধু local preview-এর জন্য। Hosting-এ অবশ্যই `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `SESSION_SECRET` Secrets হিসেবে সেট করুন। Default credentials দিয়ে public deploy করবেন না।
