require('dotenv').config();
const express = require('express');
const session = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);
const multer = require('multer');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
const ROOT = __dirname;
if (process.env.NODE_ENV==='production' && (!process.env.SESSION_SECRET || !process.env.ADMIN_EMAIL || !process.env.ADMIN_PASSWORD)) throw new Error('Set SESSION_SECRET, ADMIN_EMAIL and ADMIN_PASSWORD before production start.');
const DATA = path.join(ROOT, 'data');
const UPLOADS = path.join(ROOT, 'public', 'uploads');
fs.mkdirSync(DATA, {recursive:true}); fs.mkdirSync(UPLOADS, {recursive:true});
const read = name => JSON.parse(fs.readFileSync(path.join(DATA,name),'utf8'));
const write = (name, value) => {
  const target=path.join(DATA,name), temp=target+'.tmp';
  fs.writeFileSync(temp, JSON.stringify(value,null,2)); fs.renameSync(temp,target);
  // Keep Google Sheets updated after every local admin/order change.
  if (['products.json','settings.json','orders.json'].includes(name)) scheduleSheetsPush();
};
const ensure = (name, fallback) => { if(!fs.existsSync(path.join(DATA,name))) write(name,fallback); };
ensure('products.json',[]); ensure('settings.json',{shopName:'GADGET FUSION',whatsapp:'8801305711244',deliveryFee:0});
ensure('orders.json',[]);

// Optional Google Sheets integration. Google Apps Script acts as a small,
// authenticated bridge; the server keeps a local cache for resilience.
let sheetsPushTimer;
const sheetsConfigured = () => !!(process.env.GOOGLE_SHEETS_WEB_APP_URL && process.env.GOOGLE_SHEETS_API_KEY);
async function sheetsRequest(method='GET', body) {
  if (!sheetsConfigured()) return null;
  const baseUrl = process.env.GOOGLE_SHEETS_WEB_APP_URL;
  const url = method === 'GET' ? baseUrl + (baseUrl.includes('?') ? '&' : '?') + 'apiKey=' + encodeURIComponent(process.env.GOOGLE_SHEETS_API_KEY) : baseUrl;
  const key = process.env.GOOGLE_SHEETS_API_KEY;
  const response = await fetch(url, {
    method, headers: {'Content-Type':'application/json'},
    ...(method === 'POST' ? {body: JSON.stringify({...body, apiKey:key})} : {})
  });
  if (!response.ok) throw new Error('Google Sheets connection failed: '+response.status);
  const result = await response.json();
  if (!result.ok) throw new Error(result.error || 'Google Sheets API error');
  return result;
}
async function refreshFromSheets() {
  if (!sheetsConfigured()) return;
  try {
    const result = await sheetsRequest('GET');
    if (result.snapshot && result.snapshot.initialized === false) {
      // First connection: seed the empty spreadsheet from the existing store.
      await pushToSheets();
      return;
    }
    if (result.snapshot) {
      for (const [file, value] of Object.entries({
        'products.json':result.snapshot.products,
        'settings.json':result.snapshot.settings,
        'orders.json':result.snapshot.orders
      })) {
        if (value !== undefined) fs.writeFileSync(path.join(DATA,file), JSON.stringify(value,null,2));
      }
    }
  } catch (err) { console.error('[Google Sheets pull]', err.message); }
}
async function pushToSheets() {
  if (!sheetsConfigured()) return;
  try { await sheetsRequest('POST', {snapshot:{products:read('products.json'),settings:read('settings.json'),orders:read('orders.json')}}); }
  catch (err) { console.error('[Google Sheets push]', err.message); }
}
function scheduleSheetsPush() {
  if (!sheetsConfigured()) return;
  clearTimeout(sheetsPushTimer);
  sheetsPushTimer = setTimeout(pushToSheets, 800);
}


app.set('trust proxy', 1);
app.use(helmet({contentSecurityPolicy:false}));
app.use(express.json({limit:'1mb'}));
app.use(express.urlencoded({extended:true}));
app.use(session({
  store: new SQLiteStore({db:'sessions.sqlite',dir:DATA}),
  secret: process.env.SESSION_SECRET || 'CHANGE_THIS_SESSION_SECRET_BEFORE_DEPLOYMENT_123456789',
  resave:false, saveUninitialized:false,
  cookie:{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',maxAge:8*60*60*1000}
}));
const loginLimiter=rateLimit({windowMs:15*60*1000,max:8,standardHeaders:true,legacyHeaders:false});
const auth=(req,res,next)=>req.session && req.session.admin ? next() : res.status(401).json({error:'অনুগ্রহ করে Admin Login করুন'});
const cleanText=(v,max=500)=>String(v??'').replace(/[<>]/g,'').trim().slice(0,max);
const validImage=(buf)=>{
  if(buf.length>5*1024*1024) return false;
  return (buf[0]===0xff&&buf[1]===0xd8&&buf[2]===0xff) ||
    (buf[0]===0x89&&buf.toString('ascii',1,4)==='PNG') ||
    (buf.toString('ascii',0,4)==='RIFF'&&buf.toString('ascii',8,12)==='WEBP') ||
    (buf.toString('ascii',0,3)==='GIF');
};
const storage=multer.diskStorage({
  destination:(req,file,cb)=>cb(null,UPLOADS),
  filename:(req,file,cb)=>cb(null,crypto.randomBytes(16).toString('hex')+'.'+({ 'image/jpeg':'jpg','image/png':'png','image/webp':'webp','image/gif':'gif'}[file.mimetype]||'img'))
});
const upload=multer({storage,limits:{fileSize:5*1024*1024},fileFilter:(req,file,cb)=>{
  cb(null,['image/jpeg','image/png','image/webp','image/gif'].includes(file.mimetype));
}});
app.use('/uploads',express.static(UPLOADS,{maxAge:'7d'}));
app.get('/api/public',async (req,res)=>{
  await refreshFromSheets();
  const settings=read('settings.json');
  const products=read('products.json').filter(p=>p.active!==false);
  res.json({settings,products});
});
app.post('/api/orders',async (req,res)=>{
  await refreshFromSheets();
  const {name,phone,address,items}=req.body||{};
  if(!cleanText(name,100)||!/^(\+?88)?01[3-9]\d{8}$/.test(String(phone||'').replace(/[\s-]/g,''))||!cleanText(address,600)||!Array.isArray(items)||!items.length)
    return res.status(400).json({error:'তথ্য সঠিকভাবে পূরণ করুন'});
  const products=read('products.json');
  let subtotal=0, orderItems=[];
  for(const item of items){
    const p=products.find(x=>Number(x.id)===Number(item.id)&&x.active!==false), qty=Math.max(1,Math.min(99,Number(item.qty)||1));
    if(!p) return res.status(400).json({error:'একটি পণ্য আর উপলব্ধ নেই'});
    subtotal+=Number(p.p)*qty; orderItems.push({id:p.id,name:p.n.bn,price:Number(p.p),qty});
  }
  const fee=Math.max(0,Number(read('settings.json').deliveryFee)||0);
  const orders=read('orders.json');
  const order={id:Date.now(),createdAt:new Date().toISOString(),name:cleanText(name,100),phone:cleanText(phone,30),address:cleanText(address,600),items:orderItems,subtotal,deliveryFee:fee,total:subtotal+fee,status:'নতুন'};
  orders.unshift(order);write('orders.json',orders);res.status(201).json({ok:true,id:order.id});
});
app.post('/api/admin/login',loginLimiter,(req,res)=>{
  const email=String(req.body.email||''), password=String(req.body.password||'');
  const expectedEmail=process.env.ADMIN_EMAIL||'owner@gadgetfusion.local';
  const expectedPassword=process.env.ADMIN_PASSWORD||'ChangeMe12345!';
  const safe=(a,b)=>{const x=Buffer.from(a),y=Buffer.from(b);return x.length===y.length&&crypto.timingSafeEqual(x,y)};
  if(!safe(email,expectedEmail)||!safe(password,expectedPassword)) return res.status(401).json({error:'ইমেইল বা পাসওয়ার্ড সঠিক নয়'});
  req.session.admin=true;res.json({ok:true});
});
app.post('/api/admin/logout',auth,(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get('/api/admin/me',auth,(req,res)=>res.json({ok:true}));
app.get('/api/admin/sheets-status',auth,(req,res)=>res.json({connected:sheetsConfigured(),message:sheetsConfigured()?'Google Sheets configured':'Google Sheets not configured'}));
app.post('/api/admin/sheets-sync',auth,async (req,res)=>{
  if(!sheetsConfigured()) return res.status(400).json({error:'GOOGLE_SHEETS_WEB_APP_URL এবং GOOGLE_SHEETS_API_KEY সেট করুন'});
  await pushToSheets(); await refreshFromSheets(); res.json({ok:true});
});
app.get('/api/admin/products',auth,async (req,res)=>{await refreshFromSheets();res.json(read('products.json'));});
app.post('/api/admin/products',auth,(req,res)=>{
  const body=req.body||{}, products=read('products.json');
  const id=Date.now();
  const p={id,c:['head','bud','chg'].includes(body.c)?body.c:'head',p:Math.max(0,Number(body.p)||0),o:Math.max(0,Number(body.o)||0),bg:/^#[0-9a-f]{6}$/i.test(body.bg||'')?body.bg:'#f2f2f2',
    img:cleanText(body.img,500),n:{bn:cleanText(body.nameBn,120),en:cleanText(body.nameEn,120)},d:{bn:cleanText(body.descBn,300),en:cleanText(body.descEn,300)},active:body.active!=='false'};
  if(!p.n.bn||!p.n.en||p.p<=0) return res.status(400).json({error:'নাম ও সঠিক দাম দিন'});
  products.push(p);write('products.json',products);res.status(201).json(p);
});
app.put('/api/admin/products/:id',auth,(req,res)=>{
  const products=read('products.json'),idx=products.findIndex(p=>String(p.id)===String(req.params.id));
  if(idx<0)return res.status(404).json({error:'পণ্য পাওয়া যায়নি'});
  const b=req.body||{},old=products[idx];
  products[idx]={...old,c:['head','bud','chg'].includes(b.c)?b.c:old.c,p:Math.max(0,Number(b.p)||0),o:Math.max(0,Number(b.o)||0),bg:/^#[0-9a-f]{6}$/i.test(b.bg||'')?b.bg:old.bg,img:cleanText(b.img,500)||old.img,n:{bn:cleanText(b.nameBn,120)||old.n.bn,en:cleanText(b.nameEn,120)||old.n.en},d:{bn:cleanText(b.descBn,300),en:cleanText(b.descEn,300)},active:b.active!=='false'};
  write('products.json',products);res.json(products[idx]);
});
app.delete('/api/admin/products/:id',auth,(req,res)=>{
  const products=read('products.json'),next=products.filter(p=>String(p.id)!==String(req.params.id));
  if(next.length===products.length)return res.status(404).json({error:'পণ্য পাওয়া যায়নি'});
  write('products.json',next);res.json({ok:true});
});
app.post('/api/admin/upload',auth,(req,res)=>{
  upload.single('image')(req,res,err=>{
    if(err)return res.status(400).json({error:'ছবি ৫MB-এর কম JPG, PNG, WEBP বা GIF হতে হবে'});
    if(!req.file)return res.status(400).json({error:'ছবি নির্বাচন করুন'});
    const b=fs.readFileSync(req.file.path);
    if(!validImage(b)){fs.unlinkSync(req.file.path);return res.status(400).json({error:'ছবির ফাইলটি সঠিক নয়'});}
    res.json({url:'/uploads/'+req.file.filename});
  });
});
app.get('/api/admin/settings',auth,async (req,res)=>{await refreshFromSheets();res.json(read('settings.json'));});
app.put('/api/admin/settings',auth,(req,res)=>{
  const b=req.body||{},old=read('settings.json');
  const keys=['shopName','whatsapp','phoneDisplay','heroBn','heroEn','heroSubBn','heroSubEn','ctaBn','ctaEn','perk1Bn','perk1En','perk2Bn','perk2En','perk3Bn','perk3En','aboutBn','aboutEn','bannerImage'];
  const next={...old};for(const k of keys)if(b[k]!==undefined)next[k]=cleanText(b[k],k.includes('about')?1000:250);
  next.deliveryFee=Math.max(0,Math.min(10000,Number(b.deliveryFee)||0));
  next.whatsapp=String(next.whatsapp).replace(/\D/g,'').slice(0,15);
  if(next.whatsapp.length<10)return res.status(400).json({error:'সঠিক WhatsApp নম্বর দিন'});
  write('settings.json',next);res.json(next);
});
app.get('/api/admin/orders',auth,async (req,res)=>{await refreshFromSheets();res.json(read('orders.json'));});
app.patch('/api/admin/orders/:id',auth,(req,res)=>{
  const orders=read('orders.json'),o=orders.find(x=>String(x.id)===String(req.params.id));
  if(!o)return res.status(404).json({error:'অর্ডার পাওয়া যায়নি'});
  const allowed=['নতুন','নিশ্চিত','পাঠানো হয়েছে','সম্পন্ন','বাতিল'];
  if(!allowed.includes(req.body.status))return res.status(400).json({error:'অবস্থা সঠিক নয়'});
  o.status=req.body.status;write('orders.json',orders);res.json(o);
});
app.use(express.static(path.join(ROOT,'public')));
app.use((err,req,res,next)=>{console.error(err);res.status(500).json({error:'সার্ভারে সমস্যা হয়েছে'});});
const port=process.env.PORT||3000;
app.listen(port,'0.0.0.0',()=>console.log('Gadget Fusion running on '+port));
