/** Gadget Fusion ↔ Google Sheets bridge.
 * Set Script Properties: SPREADSHEET_ID and API_KEY before deployment.
 * Deploy as a Web App, Execute as: Me, access: Anyone.
 * The API key protects the data endpoint; never share it publicly.
 */
const PRODUCT_HEADERS = ['id','category','price','oldPrice','background','image','nameBn','nameEn','descBn','descEn','active'];
const ORDER_HEADERS = ['id','createdAt','name','phone','address','itemsJson','subtotal','deliveryFee','total','status'];

function setupSheets() {
  const ss = SpreadsheetApp.openById(PropertiesService.getScriptProperties().getProperty('SPREADSHEET_ID'));
  ensureTab_(ss, 'Products', PRODUCT_HEADERS);
  ensureTab_(ss, 'Settings', ['key','value']);
  ensureTab_(ss, 'Orders', ORDER_HEADERS);
  return 'Gadget Fusion sheets are ready';
}
function ensureTab_(ss, name, headers) {
  let sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);
  if (sh.getLastRow() === 0) sh.appendRow(headers);
  else sh.getRange(1,1,1,headers.length).setValues([headers]);
  return sh;
}
function checkKey_(key) {
  const expected = PropertiesService.getScriptProperties().getProperty('API_KEY');
  if (!expected || key !== expected) throw new Error('Unauthorized');
}
function doGet(e) {
  try {
    checkKey_(e && e.parameter && e.parameter.apiKey);
    const ss = SpreadsheetApp.openById(PropertiesService.getScriptProperties().getProperty('SPREADSHEET_ID'));
    return json_({ok:true, snapshot:readSnapshot_(ss)});
  } catch (err) { return json_({ok:false,error:String(err.message || err)}); }
}
function doPost(e) {
  try {
    const body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    checkKey_(body.apiKey);
    if (!body.snapshot) throw new Error('Missing snapshot');
    const ss = SpreadsheetApp.openById(PropertiesService.getScriptProperties().getProperty('SPREADSHEET_ID'));
    writeSnapshot_(ss, body.snapshot);
    return json_({ok:true});
  } catch (err) { return json_({ok:false,error:String(err.message || err)}); }
}
function readSnapshot_(ss) {
  const productsSheet = ss.getSheetByName('Products');
  const settingsSheet = ss.getSheetByName('Settings');
  const ordersSheet = ss.getSheetByName('Orders');
  const products = rowsAsObjects_(productsSheet, PRODUCT_HEADERS).map(r => ({
    id:Number(r.id), c:String(r.category || 'head'), p:Number(r.price || 0), o:Number(r.oldPrice || 0),
    bg:String(r.background || '#f2f2f2'), img:String(r.image || ''),
    n:{bn:String(r.nameBn || ''),en:String(r.nameEn || '')},
    d:{bn:String(r.descBn || ''),en:String(r.descEn || '')}, active:String(r.active).toLowerCase() !== 'false'
  }));
  const settings = {};
  if (settingsSheet && settingsSheet.getLastRow() > 1) {
    settingsSheet.getRange(2,1,settingsSheet.getLastRow()-1,2).getValues().forEach(row => {
      if (row[0] !== '') settings[String(row[0])] = row[1];
    });
  }
  if (settings.deliveryFee !== undefined) settings.deliveryFee = Number(settings.deliveryFee) || 0;
  const orders = rowsAsObjects_(ordersSheet, ORDER_HEADERS).map(r => ({
    id:Number(r.id), createdAt:String(r.createdAt || ''), name:String(r.name || ''), phone:String(r.phone || ''),
    address:String(r.address || ''), items:parseJson_(r.itemsJson, []), subtotal:Number(r.subtotal || 0),
    deliveryFee:Number(r.deliveryFee || 0), total:Number(r.total || 0), status:String(r.status || 'নতুন')
  }));
  const initialized = !!((productsSheet && productsSheet.getLastRow() > 1) || (settingsSheet && settingsSheet.getLastRow() > 1) || (ordersSheet && ordersSheet.getLastRow() > 1));
  return {products, settings, orders, initialized};
}
function writeSnapshot_(ss, snapshot) {
  const p = ensureTab_(ss, 'Products', PRODUCT_HEADERS);
  const st = ensureTab_(ss, 'Settings', ['key','value']);
  const o = ensureTab_(ss, 'Orders', ORDER_HEADERS);
  replaceRows_(p, PRODUCT_HEADERS, (snapshot.products || []).map(x => [x.id,x.c,x.p,x.o,x.bg,x.img,x.n && x.n.bn,x.n && x.n.en,x.d && x.d.bn,x.d && x.d.en,x.active !== false]));
  replaceRows_(st, ['key','value'], Object.entries(snapshot.settings || {}));
  replaceRows_(o, ORDER_HEADERS, (snapshot.orders || []).map(x => [x.id,x.createdAt,x.name,x.phone,x.address,JSON.stringify(x.items || []),x.subtotal,x.deliveryFee,x.total,x.status]));
}
function replaceRows_(sheet, headers, rows) {
  sheet.clearContents();
  sheet.getRange(1,1,1,headers.length).setValues([headers]);
  if (rows.length) sheet.getRange(2,1,rows.length,headers.length).setValues(rows);
  sheet.setFrozenRows(1);
}
function rowsAsObjects_(sheet, headers) {
  if (!sheet || sheet.getLastRow() < 2) return [];
  return sheet.getRange(2,1,sheet.getLastRow()-1,headers.length).getValues().map(row => {
    const obj = {}; headers.forEach((h,i) => obj[h] = row[i]); return obj;
  }).filter(x => x.id !== '' && x.id !== null);
}
function parseJson_(value, fallback) { try { return JSON.parse(value || ''); } catch (_) { return fallback; } }
function json_(obj) { return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON); }
