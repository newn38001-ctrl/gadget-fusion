# Gadget Fusion — মোবাইল Admin Panel সহ

## কী আছে
- আগের Gadget Fusion ডিজাইন এবং ৫টি পণ্য ও তাদের মূল ছবি
- বাংলা/ইংরেজি storefront
- ফোনের Gallery থেকে পণ্যের ছবি আপলোড (JPG, PNG, WEBP, GIF; সর্বোচ্চ 5 MB)
- পণ্যের নাম, দাম, আগের দাম, বিবরণ, ক্যাটাগরি, ছবি ও show/hide পরিবর্তন
- হোমপেজের শিরোনাম, লেখা, ব্যানার ছবি, WhatsApp/ফোন নম্বর, পরিচিতি ও ডেলিভারি চার্জ পরিবর্তন
- অর্ডার সংরক্ষণ ও Admin Panel থেকে status পরিবর্তন
- আলাদা Admin Login

## Replit-এ চালানোর নিয়ম (Android ফোন থেকেও)
1. এই ZIP Replit-এ Import করুন।
2. Replit Shell-এ `npm install` চালান।
3. Secrets / Environment Variables-এ `.env.example`-এর মানগুলো যোগ করুন। `SESSION_SECRET`-এ অন্তত 32 অক্ষরের নতুন random secret এবং `ADMIN_PASSWORD`-এ অন্তত 12 অক্ষরের শক্ত পাসওয়ার্ড দিন।
4. Run command `npm start` রাখুন।
5. Preview খুলে storefront দেখুন। Admin Panel: `/admin.html`।
6. Admin Login-এ আপনার `ADMIN_EMAIL` ও `ADMIN_PASSWORD` ব্যবহার করুন।

## ডেটা সংরক্ষণ
`data/` ফোল্ডারে products, settings, orders এবং SQLite session database থাকে। `public/uploads/`-এ আপলোড করা ছবি থাকে। Hosting provider-এ persistent disk/volume যুক্ত করতে হবে এবং এই ফোল্ডারগুলো deploy/restart-এর পরও সংরক্ষিত থাকে কি না নিশ্চিত করতে হবে। শুধু ephemeral filesystem-এ চালালে redeploy হলে ডেটা/ছবি হারাতে পারে।

## গুরুত্বপূর্ণ সীমাবদ্ধতা ও প্রকাশের আগে করণীয়
- এই প্যাকেজে কোনো online payment gateway নেই। Storefront-এর অর্ডার WhatsApp-এ পাঠানো হয় এবং একই সঙ্গে server-এ order record তৈরি হয়।
- বর্তমান অর্ডার flow পণ্যের stock কমায় না; inventory accounting যোগ করা দরকার হলে পরের ধাপে করা যাবে।
- Admin password environment variables-এ রাখুন; `.env` কখনো public repository-তে commit করবেন না।
- HTTPS-সহ hosting ব্যবহার করুন, persistent storage নিশ্চিত করুন, নিজের ফোনে customer order এবং admin edits পরীক্ষা করুন।
- এই build-এর source files তৈরি ও syntax-check করা হয়েছে; এখানে live hosting, payment, real device end-to-end testing বা production security audit করা হয়নি। তাই যাচাই ছাড়া production-ready ধরে নেবেন না।

## ডিফল্ট লগইন
কোডে fallback credentials আছে শুধু local preview-এর জন্য। Hosting-এ অবশ্যই `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `SESSION_SECRET` Secrets হিসেবে সেট করুন। Default credentials দিয়ে public deploy করবেন না।

## Google Sheets দিয়ে পুরো ওয়েবসাইট নিয়ন্ত্রণ

এই সংস্করণে Google Sheets সংযোগের সুবিধা যোগ করা হয়েছে। `Products`, `Settings`, `Orders` নামে তিনটি ট্যাব তৈরি হবে। Sheets-এ পরিবর্তন করলে পরের ওয়েবসাইট/API লোডে ডেটা আপডেট হবে; Admin Panel বা ক্রেতার নতুন অর্ডার থেকেও পরিবর্তন Sheets-এ পাঠানো হবে। প্রথম সংযোগে খালি Sheet-এ বর্তমান ওয়েবসাইটের ডেটা কপি হবে।

### ধাপ ১ — Google Spreadsheet তৈরি
1. Android ফোনে https://sheets.google.com খুলে Blank spreadsheet তৈরি করুন। নাম দিন `Gadget Fusion Control`।
2. Spreadsheet URL থেকে `/d/` এবং `/edit`-এর মাঝের অংশটি কপি করুন। এটিই `SPREADSHEET_ID`।

### ধাপ ২ — Apps Script তৈরি ও সেটআপ
1. Spreadsheet-এ Extensions → Apps Script খুলুন।
2. এ ZIP-এর `google-apps-script/Code.gs` ফাইলের সম্পূর্ণ কোড Apps Script-এর editor-এ পেস্ট করুন।
3. Project Settings → Script Properties-এ দুটি property যোগ করুন:
   - `SPREADSHEET_ID` = ধাপ ১-এর ID
   - `API_KEY` = নিজের তৈরি দীর্ঘ, এলোমেলো গোপন key (কমপক্ষে 32 অক্ষর)। এটি কাউকে দেবেন না।
4. Editor থেকে `setupSheets` ফাংশন একবার Run করুন এবং Google permission অনুমোদন করুন। এতে তিনটি ট্যাব/হেডার তৈরি হবে।
5. Deploy → New deployment → Web app নির্বাচন করুন। Execute as: **Me** এবং Who has access: **Anyone** নির্বাচন করে Deploy করুন। Google-এর দেওয়া Web app URL কপি করুন।

### ধাপ ৩ — Replit Secrets
Replit-এর Secrets / Environment Variables-এ এই দুটি secret যোগ করুন:
- `GOOGLE_SHEETS_WEB_APP_URL` = Apps Script Web app URL
- `GOOGLE_SHEETS_API_KEY` = Script Properties-এ দেওয়া একই API_KEY

আগের `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `SESSION_SECRET`-ও অবশ্যই সেট রাখুন। এরপর Replit-এ Stop করে আবার Run দিন।

### ধাপ ৪ — প্রথম সংযোগ
1. ওয়েবসাইটের `/admin.html` খুলে Admin Login করুন।
2. ওয়েবসাইটের হোমপেজ একবার খুলুন। প্রথম সংযোগে খালি Spreadsheet-এ বর্তমান পণ্য/সেটিংস/অর্ডারের ডেটা কপি হবে।
3. Google Sheets-এ `Products`, `Settings`, `Orders` ট্যাব দেখুন।

### Sheet-এ কোন কলাম বদলাবেন
- **Products:** `id`, `category`, `price`, `oldPrice`, `background`, `image`, `nameBn`, `nameEn`, `descBn`, `descEn`, `active`। `active`-এ TRUE/FALSE দিন। `category` হবে `head`, `bud`, অথবা `chg`। নতুন পণ্য যোগ করতে নতুন row যোগ করুন; `id` ইউনিক সংখ্যা হতে হবে। `image`-এ ওয়েব থেকে খোলা যায় এমন image URL বা সাইটের `/uploads/...` path দিন।
- **Settings:** A কলামে key, B কলামে value। যেমন `shopName`, `whatsapp`, `deliveryFee`, `heroBn`, `heroEn`, `heroSubBn`, `heroSubEn`, `ctaBn`, `ctaEn`, `perk1Bn`, `perk1En`, `perk2Bn`, `perk2En`, `perk3Bn`, `perk3En`, `aboutBn`, `aboutEn`, `bannerImage`, `phoneDisplay`। বিদ্যমান key-এর value বদলান; নতুন key যোগ করলেও ওয়েবসাইটে ব্যবহার না থাকলে দৃশ্যমান হবে না।
- **Orders:** অর্ডার ওয়েবসাইট থেকে নিজে নিজে যোগ হবে। `status` কলামে `নতুন`, `নিশ্চিত`, `পাঠানো হয়েছে`, `সম্পন্ন`, `বাতিল` ব্যবহার করুন। `itemsJson` কলাম হাতে সম্পাদনা করবেন না।

### গুরুত্বপূর্ণ
- Sheet-এর পরিবর্তন ওয়েবসাইটের পরবর্তী ডেটা রিফ্রেশে দেখা যাবে; তাৎক্ষণিক লাইভ push নয়।
- Products/Settings/Orders ট্যাবের header row বা কলামের ক্রম বদলাবেন না; row delete করে তথ্য মুছতে পারেন।
- ছবি ফাইল Google Sheets-এ আপলোড হয় না; `image`/`bannerImage`-এ অনলাইনে অ্যাক্সেসযোগ্য URL দিতে হবে। Admin Panel দিয়ে আপলোড করা ছবি Replit-এর persistent storage-এ রাখতে হবে।
- Apps Script deployment URL ও API key গোপন রাখুন। ভুল key দিলে সংযোগ হবে না।
- প্রথম sync-এর আগে Spreadsheet খালি রাখুন। বিদ্যমান Sheet-এর ডেটা প্রথম সংযোগে authoritative হিসেবে ব্যবহৃত হবে।
- Replit hosting-এ `data/` এবং `public/uploads/`-এর persistent storage চালু রাখুন।
